Before opening the website please check that the required fonts are installed.

All the required fonts can be found in the fonts directory.